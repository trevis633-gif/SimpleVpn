# Simple VPN (Android, WireGuard)

Клиент WireGuard: Kotlin + Jetpack Compose + официальная библиотека `com.wireguard.android:tunnel`.

## Важно
Приложение — только **клиент**. Нужен VPN-сервер с WireGuard:
свой VPS (WireGuard / PiVPN / wg-easy) или готовый конфиг от провайдера.
Конфиг вставляется в приложение или импортируется из .conf-файла.

## Получить APK без Android Studio (через GitHub)
1. Создайте репозиторий на github.com и загрузите в него **всё содержимое** папки проекта
   (включая скрытую папку `.github`). Проще с компьютера: `git push` или перетаскивание папки в браузер.
2. Вкладка **Actions** → **Build APK** → сборка стартует сама (или кнопка Run workflow).
3. Через 3–5 минут откройте завершённый запуск → внизу **Artifacts** → `SimpleVpn-debug-apk`.
4. Распакуйте, перенесите `app-debug.apk` на телефон и установите
   (разрешите установку из неизвестных источников).

## Сборка в Android Studio
1. Android Studio (Koala или новее), JDK 17.
2. File → Open → папка SimpleVpn, дождаться Gradle Sync.
3. Run на устройстве/эмуляторе (minSdk 24).
4. При первом подключении Android покажет системный запрос на VPN.

## Формат конфига
    [Interface]
    PrivateKey = <ключ клиента>
    Address = 10.0.0.2/32
    DNS = 1.1.1.1

    [Peer]
    PublicKey = <ключ сервера>
    Endpoint = your.server.com:51820
    AllowedIPs = 0.0.0.0/0

Раздельное туннелирование поддерживается библиотекой:
в [Interface] добавьте `ExcludedApplications = com.example.app1, com.example.app2`
(или `IncludedApplications = ...`).

## Что доработать для продакшена
- Хранить конфиг/ключ в Android Keystore, а не в SharedPreferences.
- Foreground-уведомление со статусом и кнопкой «Отключить».
- Kill switch: Настройки Android → VPN → «Всегда включённый VPN» + «Блокировать соединения без VPN».
- Импорт по QR-коду, несколько профилей, статистика трафика (`backend.getStatistics`).
- Иконка, локализация в strings.xml, release-подпись, декларация VPN для Google Play.

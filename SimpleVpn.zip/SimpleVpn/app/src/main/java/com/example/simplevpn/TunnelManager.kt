package com.example.simplevpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayInputStream

sealed interface VpnStatus {
    data object Disconnected : VpnStatus
    data object Connecting : VpnStatus
    data object Connected : VpnStatus
    data class Error(val message: String) : VpnStatus
}

class TunnelManager(context: Context) {

    private val backend = GoBackend(context.applicationContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()

    private val _status = MutableStateFlow<VpnStatus>(VpnStatus.Disconnected)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val tunnel = object : Tunnel {
        // Имя: 1–15 символов из [a-zA-Z0-9_=+.-]
        override fun getName(): String = "vpn0"

        // Вызывается и когда систему/пользователь сам остановил VPN
        override fun onStateChange(newState: Tunnel.State) {
            when (newState) {
                Tunnel.State.UP -> _status.value = VpnStatus.Connected
                Tunnel.State.DOWN ->
                    if (_status.value !is VpnStatus.Error) _status.value = VpnStatus.Disconnected
                else -> Unit
            }
        }
    }

    fun connect(configText: String) {
        scope.launch {
            lock.withLock {
                _status.value = VpnStatus.Connecting
                try {
                    val config = Config.parse(ByteArrayInputStream(configText.toByteArray()))
                    backend.setState(tunnel, Tunnel.State.UP, config)
                    _status.value = VpnStatus.Connected
                } catch (e: Exception) {
                    _status.value = VpnStatus.Error(e.message ?: e.javaClass.simpleName)
                }
            }
        }
    }

    fun disconnect() {
        scope.launch {
            lock.withLock {
                try {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    _status.value = VpnStatus.Disconnected
                } catch (e: Exception) {
                    _status.value = VpnStatus.Error(e.message ?: e.javaClass.simpleName)
                }
            }
        }
    }
}

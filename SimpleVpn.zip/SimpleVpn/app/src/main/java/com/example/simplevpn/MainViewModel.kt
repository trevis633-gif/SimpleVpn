package com.example.simplevpn

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val manager = (app as VpnApp).tunnelManager
    private val prefs = app.getSharedPreferences("vpn", Context.MODE_PRIVATE)

    val status: StateFlow<VpnStatus> = manager.status

    var configText by mutableStateOf(prefs.getString(KEY_CONFIG, "") ?: "")
        private set

    fun updateConfig(text: String) {
        configText = text
        prefs.edit().putString(KEY_CONFIG, text).apply()
    }

    fun importFrom(uri: Uri) {
        try {
            val text = getApplication<Application>().contentResolver
                .openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!text.isNullOrBlank()) updateConfig(text)
        } catch (_: Exception) {
            // файл не прочитался — оставляем текущий конфиг
        }
    }

    fun connect() = manager.connect(configText)
    fun disconnect() = manager.disconnect()

    private companion object {
        const val KEY_CONFIG = "wg_config"
    }
}

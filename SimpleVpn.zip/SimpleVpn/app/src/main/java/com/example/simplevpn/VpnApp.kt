package com.example.simplevpn

import android.app.Application

class VpnApp : Application() {
    // Один экземпляр на весь процесс: GoBackend должен жить, пока работает туннель
    lateinit var tunnelManager: TunnelManager
        private set

    override fun onCreate() {
        super.onCreate()
        tunnelManager = TunnelManager(this)
    }
}
